from math import *

print(log2(10000000))